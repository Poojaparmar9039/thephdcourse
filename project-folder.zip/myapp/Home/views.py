from django.shortcuts import render

def home(request):
    return render(request,'Home.html')

def checkout_page(request):
    return render(request,'checkout.html')
